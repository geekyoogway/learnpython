from flask import Flask, render_template, request
import pandas as pd
from wtforms import SubmitField
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired
from flask_paginate import Pagination, get_page_args


app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'

# Assuming you have a DataFrame named 'df'
df = pd.DataFrame({
    'Name': ['John', 'Alice', 'Bob'] * 100,  # Example data with repeated rows
    'Age': [25, 30, 35] * 100,
    'City': ['New York', 'London', 'Paris'] * 100
})

class SortForm(FlaskForm):
    submit = SubmitField('Sort')
    search_query = StringField('Search', validators=[DataRequired()])
    submit = SubmitField('Search')

@app.route('/', methods=['GET', 'POST'])
def sort():
    global df 
    columns = df.columns.tolist()
    page, per_page, offset = get_page_args(page_parameter='page', per_page_parameter='per_page')
    
    search_query = request.args.get('search_query', default='', type=str)
    df = df[df.apply(lambda row: search_query.lower() in ' '.join(str(row.values)).lower(), axis=1)]

    pagination = Pagination(page=page, total=len(df), record_name='results', per_page=per_page, css_framework='bootstrap4')
    start = (page - 1) * per_page
    end = start + per_page
    df = df[start:end]
    # df = df[offset: offset + per_page]

    form = SortForm()
    search_query = form.search_query.data

    if form.validate_on_submit():
        # search_query = form.search_query.data


        sort_column = request.form['sort_column']
        sort_order = request.form['sort_order']

        if sort_column in df.columns:
            df.sort_values(by=sort_column, ascending=(sort_order == 'asc'), inplace=True)

    return render_template('sort.html', form=form, dataframe=df, columns=columns,pagination=pagination, search_query=search_query)

if __name__ == '__main__':
    app.run()
